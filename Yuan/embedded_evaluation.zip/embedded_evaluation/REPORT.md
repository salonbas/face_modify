# 人臉辨識模型部署與系統效能評估

本報告以實際執行取得的 CSV、procfs、Windows CIM 與模型資產 SHA-256 為依據。實測日期為 2026-11-26（Asia/Taipei）。本輪代表模型為 **MobileFaceNet**；五模型只做部署資產核對，沒有重跑完整五模型研究、訓練或產生對抗影像。

## 一、實際系統架構

Windows 11 x86-64 → WSL2 Ubuntu x86-64 → QEMU ARM64 virt／TCG → Ubuntu aarch64 → CPUExecutionProvider → MobileFaceNet 與 SCRFD。Windows 瀏覽器透過 localhost:8000 轉送到 Guest 的 FastAPI；SSH localhost:2222 用於操作 Guest。虛擬板為 QEMU virt，並非 Raspberry Pi 板級模擬。

```mermaid
flowchart LR
    H["Windows x86-64 Host / Browser"] --> W["WSL2 Ubuntu x86-64 virtualization"]
    W --> Q["QEMU TCG ARM64 virt / Cortex-A72"]
    Q --> G["Ubuntu aarch64 / FastAPI"]
    G --> M["CPU ORT / SCRFD + MobileFaceNet"]
```


| 層級 | 實際規格 |
| --- | --- |
| Windows Host | Microsoft Windows 11 家用版 10.0.26200 build 26200 |
| Host CPU | Intel Core i7-13620H；10 實體核心、16 邏輯處理器 |
| Host RAM | 34359738368 bytes＝32 GiB 已安裝；OS 可見 34048851968 bytes |
| WSL2 | WSL 3.0.5；Ubuntu 26.04.1 x86_64；6.18.58.1-microsoft-standard-WSL2 |
| WSL 資源 | 16 邏輯 CPU；MemTotal 約 15.474 GiB（當次 procfs 上限，非實體 RAM） |
| QEMU | 10.2.1；virt,gic-version=3；cortex-a72；4 vCPU；4096 MiB；-accel tcg,thread=multi |
| Guest | Ubuntu 24.04.5 LTS；6.8.0-147-generic；aarch64 |
| Guest 資源 | CPU affinity [0, 1, 2, 3]；MemTotal 4090650624 bytes；無 swap |
| 加速 | ORT CPUExecutionProvider；intra-op 2、inter-op 1；OpenCV 1；無 ARM KVM／GPU 推論 |
| 執行限制 | 單模型程序；MemoryMax 3500 MiB、TasksMax 64；非 CPU quota |

WSL2 是 x86-64 Linux 虛擬化；QEMU TCG 才負責將 ARM64 指令轉譯到 x86-64。Guest 中 Python 與推論套件都是 aarch64 二進位，執行在模擬 CPU 上；數據不能當成實體 Cortex-A72、Raspberry Pi 或原生 ARM 裝置效能。Host 雖有 NVIDIA RTX 3050 Laptop GPU 與 Intel UHD，Guest 的實際 provider 僅 CPU。

原始證據：`logs/windows_environment.json`、`logs/wsl_environment.json`、`logs/wsl_version.txt`、`logs/wsl_distributions.txt`、`logs/guest_environment.json`、`logs/guest_system_evidence.txt`。實際 QEMU 完整指令保存在 WSL JSON。本輪未做核心數、affinity 或執行緒組數比較；4 vCPU、ORT 執行緒2、Guest affinity 0–3是不同概念。

## 二、模型、權重與來源

部署固定參照 `salonbas/face_modify` commit `b290fcffca8fa0ac91e3d8199127bbfb324e86cd` 的 `Yeah` 模組與既有校準門檻。全部部署資產逐檔核對 SHA-256；每檔名稱、格式、bytes、MiB、實際與預期 SHA-256 及來源寫入 `model_info.json`。完整 SHA 不以縮寫代替。

| 模型 | 引擎 | 主權重 | MiB | 固定門檻 | 本輪範圍 |
| --- | --- | --- | --- | --- | --- |
| arcface | onnxruntime | w600k_r50.onnx | 166.305 | 0.14072093367576602 | 本輪僅資產核對 |
| facenet | pytorch_cpu | 20180402-114759-vggface2.pt | 106.715 | 0.4088586568832398 | 本輪僅資產核對 |
| adaface | pytorch_cpu | adaface_ir50_ms1mv2.ckpt | 667.845 | 0.14697599411010745 | 本輪僅資產核對 |
| mobilefacenet | onnxruntime | w600k_mbf.onnx | 12.985 | 0.1633139401674271 | MobileFaceNet 實測 |
| magface | pytorch_cpu | magface_iresnet100_ms1mv2.pth | 269.928 | 0.18449912965297702 | 本輪僅資產核對 |

MobileFaceNet 主權重 SHA-256：`9cc6e4a75f0e2bf0b1aed94578f144d15175f357bdc05e815e5c4a02b319eb4f`。來源為設定檔記錄的 InsightFace buffalo_sc／WebFace600K 模型。SCRFD 偵測器及主模型各自的檔案大小與 SHA 見 JSON；兩者共同完成驗證，不能僅以主權重大小代表整個執行環境。權重不包含於本成果 ZIP。

MobileFaceNet 輸入：原始 JPEG/PNG 先經 PIL EXIF 方向處理、RGB 解碼轉 BGR；SCRFD 640×640 偵測，以原 adapter 的 `max_num=1` 選臉；五個 landmarks 做 `norm_crop` 112×112；InsightFace `get_feat` 建立 RGB NCHW float32 tensor，mean/std=127.5/127.5。辨識 ONNX 輸入／輸出為 `[{'name': 'input.1', 'shape': ['None', 3, 112, 112], 'type': 'tensor(float)'}]`／`[{'name': '516', 'shape': [1, 512], 'type': 'tensor(float)'}]`，本次固定 batch=1。輸出 512 維向量；服務端以 float64 L2 正規化、向量內積取得 cosine，cosine ≥ **0.1633139401674271** 判為同人。純模型試驗的 tensor 在計時前準備，沒有把偵測器納入純辨識延遲。

門檻來自 `Yeah/results/calibration/mobilefacenet_lfw_v2/thresholds.json`，為既有 FAR 1e-2 校準門檻；其 SHA 保存在 model_info 的 calibration 欄位。未根據本輪結果修改門檻，也未將設定檔中的歷史 held-out 指標視為新測試。

Python 與主要版本：3.12.3 (main, Aug 31 2026, 10:18:26) [GCC 13.3.0]；套件實際版本 `{'numpy': '1.26.4', 'pillow': '10.2.0', 'opencv-python-headless': '4.10.0.84', 'opencv-python': None, 'onnxruntime': '1.26.0', 'onnx': '1.17.0', 'torch': '2.2.2', 'torchvision': '0.17.2', 'insightface': '0.7.3', 'facenet-pytorch': '2.6.0'}`。補充版本（正式量測後唯讀取得）：`{'scipy': '1.17.1', 'scikit-image': '0.26.0', 'fastapi': '0.115.12', 'uvicorn': '0.34.2'}`。原辨識 adapter 的已安裝版本原始碼保留於 `logs/installed_recognition_adapter.py`，部署 backend/core/worker/API snapshot 位於 `logs/deployed_source/`，與 Guest 原碼 SHA 對照於環境資料。

### 與 Yuan 研究程式的關係

使用者提供的 `C:/senior_project/face_modify/Yuan` 為唯讀查核來源；其說明指向相鄰 `Yeah` 的 LFW 資料。MobileFaceNet 是 `Yeah` 五模型部署中的代表，不能說成已核對 Yuan 三模型實驗的所有結果。特別是 Yuan AdaFace IR50/WebFace4M 權重 SHA `43bd2d570584d95d4a17ce81f26449034c45dbeed750afcab651872abc0e1496`，與 Guest 的 IR50/MS1MV2 權重、色彩協議與門檻不同；本輪未對其宣稱輸出等價。其他四模型本輪的功能與延遲為 N/A，原因是本次明確只量測代表模型，未重新執行完整五模型實驗。

## 三、Development 功能驗證

依 `attack_dev.csv` 既定順序，選取同時出現在固定 commit 的 v2 `development.csv` 前六個身份，使用原始 A=0001、B=0002 JPEG（皆為250×250 RGB，實際檔頭見 logs/input_image_headers.json）。12 張照片逐一 SHA 核對，且與原研究的 reference/probe SHA 相同。六組同人、六組循環跨身份配對，預期值由 identity ID 產生，沒有依模型分數篩選。來源、選取規則、SHA 與配對清單全部寫入 `data_provenance.json`；未使用 OOS、Test、Reserve 影像。

測試 12 筆；正常 12、失敗 0；預期／實際一致 12/12。這是小型 Development 功能檢查，不能推論母體辨識率、FAR／FRR，也不是正式盲測準確率。完整錯誤欄位與每筆時間見 `validation_results.csv`。

| Sample ID | 預期 | 實際 | Cosine | 門檻 | 偵測 | 執行 |
| --- | --- | --- | --- | --- | --- | --- |
| DEV-POS-01 | same_person | same_person | 0.764 | 0.1633139401674271 | A:ok;B:ok | ok |
| DEV-POS-02 | same_person | same_person | 0.638 | 0.1633139401674271 | A:ok;B:ok | ok |
| DEV-POS-03 | same_person | same_person | 0.506 | 0.1633139401674271 | A:ok;B:ok | ok |
| DEV-POS-04 | same_person | same_person | 0.750 | 0.1633139401674271 | A:ok;B:ok | ok |
| DEV-POS-05 | same_person | same_person | 0.650 | 0.1633139401674271 | A:ok;B:ok | ok |
| DEV-POS-06 | same_person | same_person | 0.561 | 0.1633139401674271 | A:ok;B:ok | ok |
| DEV-NEG-01 | different_person | different_person | -0.019 | 0.1633139401674271 | A:ok;B:ok | ok |
| DEV-NEG-02 | different_person | different_person | -0.061 | 0.1633139401674271 | A:ok;B:ok | ok |
| DEV-NEG-03 | different_person | different_person | 0.058 | 0.1633139401674271 | A:ok;B:ok | ok |
| DEV-NEG-04 | different_person | different_person | 0.078 | 0.1633139401674271 | A:ok;B:ok | ok |
| DEV-NEG-05 | different_person | different_person | 0.054 | 0.1633139401674271 | A:ok;B:ok | ok |
| DEV-NEG-06 | different_person | different_person | -0.050 | 0.1633139401674271 | A:ok;B:ok | ok |

### 與原研究 clean 輸出核對

六組同人配對能核對相同原圖 SHA、MobileFaceNet 權重與既有門檻，與原研究 JSON 中的 **clean_cosine** 比較，不比較其攻擊影像或重做攻擊。原紀錄照原樣保存在 `logs/upstream_records/`。預設絕對容許誤差 1e-5 不作事後放寬。

| Sample ID | 原研究 clean cosine | ARM64 cosine | 絕對差 | ≤1e-5 |
| --- | --- | --- | --- | --- |
| DEV-POS-01 | 0.7636584498678713 | 0.7636544791748314 | 3.97069304e-06 | True |
| DEV-POS-02 | 0.6382814645767212 | 0.6381211006898868 | 0.000160363887 | False |
| DEV-POS-03 | 0.506240964679833 | 0.5062553464016804 | 1.43817218e-05 | False |
| DEV-POS-04 | 0.7502508163452148 | 0.7502415713641719 | 9.24498104e-06 | True |
| DEV-POS-05 | 0.6503237873508804 | 0.6502768877754994 | 4.68995754e-05 | False |
| DEV-POS-06 | 0.56128747001737 | 0.5612633785165717 | 2.40915008e-05 | False |

其中 2/6 組在容許誤差內。判定一致不代表逐位元或數值等價：原環境為 macOS ARM64，本輪是 Linux ARM64 TCG，OpenCV 等版本及推論執行條件仍可能不同。本輪沒有保存各層中間張量，無法定位差異來源；因此原因標示未確認，不將差異全數歸因於硬體。原紀錄的權重／輸入相符，也不足以證明完整前處理協議逐位元一致。

## 四、量測方法與延遲

量測程序 PID 12307，Guest `time.perf_counter_ns()` 單調時鐘；ms=ns/1e6。先完成模型載入與功能驗證，再對固定同人配對 DEV-POS-01（Michelle_Collins 原始 A/B；以首組兩臉偵測成功者選取，非依相似度選取）分別執行兩種 series，各5次 warm-up、30次正式，batch=1。另有前置驗證／instrumentation check，不計入70筆延遲資料。模型始終已載入，同一程序順序執行，沒有並行推論。

- `recognition_onnx_only`：固定對齊並正規化 tensor → blocking recognition `session.run`，一張臉；不含 JPEG、偵測、對齊、前處理、L2／cosine。
- `resident_full_verification`：兩個檔案 read → JPEG decode → 各自 SCRFD 偵測 → 對齊 → 各自辨識 → L2／cosine／門檻；一對照片。包括實際 core.decide 設定檔讀取；不含模型冷載入、HTTP、上傳或 worker 啟動。

| 範圍（ms） | 有效／嘗試 | Mean | P50 | P95 | Min | Max | 樣本標準差 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| recognition_onnx_only | 30/30 | 3,458.213 | 3,240.032 | 5,008.658 | 2,310.171 | 5,794.254 | 920.714 |
| resident_full_verification | 30/30 | 19,921.327 | 18,432.512 | 26,885.343 | 16,430.542 | 29,089.133 | 3,268.809 |

P95 為排序後 `(n-1)*0.95` 的線性插值；標準差為樣本標準差 ddof=1；所有成功值包含異常高／低值，不裁切。錯誤嘗試保留於 raw CSV，僅從有效延遲統計排除。`checks.json` 及 `scripts/summarize.py` 可重新計算。兩種 series 各自比較範圍不同，一張臉與一對照片不可當成同一工作量。

| 階段（兩張影像合計） | Mean ms | P50 ms | P95 ms |
| --- | --- | --- | --- |
| file_read_ms | 11.493 | 10.963 | 20.186 |
| image_decode_ms | 74.896 | 75.594 | 123.458 |
| detection_ms | 13,543.241 | 12,497.357 | 19,585.385 |
| alignment_ms | 62.816 | 54.769 | 125.418 |
| recognition_with_preprocessing_ms | 6,205.752 | 5,860.570 | 7,727.080 |
| recognition_ort_ms | 6,193.496 | 5,848.986 | 7,713.021 |
| similarity_ms | 18.659 | 19.251 | 28.321 |

偵測階段平均 13,543.241 ms，約占完整流程平均 68.0%，是本次範圍內最大的耗時階段；這是 wall-time 階段占比，並非 CPU 指令占比。

上述細分為兩張照片合計。`recognition_ort_ms` 包含在 `recognition_with_preprocessing_ms` 內，不能重複相加；其餘未包裝的 adapter／Python 開銷使階段總和不必等於整體時間。包裝只在獨立量測程序的記憶體中進行，沒有修改部署原碼；包裝前後 cosine 差與檢核結果見 `logs/instrumentation_check.json`。

初始化依賴 import 3,222.641 ms；backend 模型建立 70,751.377 ms（單筆，包含 lazy library import 與兩個 ORT session；資產先做過雜湊，因此不是未快取磁碟冷啟動）。沒有對啟動時間做30次統計。

### 展示服務與量測程序的差別

現有 API 每次驗證會啟動短生命週期 worker、核對資產、載入模型、執行兩張影像，再離開。正式 resident benchmark 使用既有 adapter，模型僅載入一次，因此表格不能直接當作使用者點擊按鈕到結果出現的延遲。量測期間停止 faceverify 展示服務以減少輪詢干擾，結束後恢復；未改動研究權重、模型門檻、部署程式或模型演算法。

本次另以相同 Development A/B 執行展示 API 單次冷程序觀測：瀏覽器按鍵至診斷指令與推論回應合計 134,756.800 ms，服務端回報請求處理 133,193.905 ms。前者包含四個診斷指令，後者排除上傳與初步解碼；不是同一計時範圍。Web CLI 為受限的 Guest 診斷介面，執行真實命令與接收模型回應，並不是任意 shell。完整回應保留於 `logs/production_http_observation.json`。這是一筆觀測，沒有 30 次正式樣本，冷 API 的 Mean/P95/標準差均為 N/A。

## 五、CPU 與記憶體

| 量測對象 | 區間／指標 | 數值 | 單位／基準 |
| --- | --- | --- | --- |
| Guest 量測程序 | 全程序 lifetime Peak RSS | 375.359 | MiB；getrusage，不含 QEMU |
| Guest 量測程序 | 全程序 user CPU Time | 3,519.685 | s |
| Guest 量測程序 | 全程序 system CPU Time | 98.176 | s |
| Guest 量測程序 | recognition_onnx_only 平均 CPU | 275.692 | %（一核心=100%；四核心上限400%） |
| Guest 量測程序 | resident_full_verification 平均 CPU | 306.208 | %（一核心=100%；四核心上限400%） |
| Guest 量測程序 | recognition_onnx_only 平均 CPU／Guest容量 | 68.923 | %（四 vCPU 總容量=100%） |
| Guest 量測程序 | resident_full_verification 平均 CPU／Guest容量 | 76.552 | %（四 vCPU 總容量=100%） |
| WSL QEMU 程序 | recognition_onnx_only 取樣最大 RSS | 5,369.219 | MiB；包含 Guest RAM 與模擬器 |
| WSL QEMU 程序 | resident_full_verification 取樣最大 RSS | 5,370.172 | MiB；包含 Guest RAM 與模擬器 |
| Windows 整機 | recognition_onnx_only 平均 CPU | 37.211 | %（整機16邏輯CPU容量=100%） |
| Windows 整機 | resident_full_verification 平均 CPU | 36.221 | %（整機16邏輯CPU容量=100%） |

Guest 每約1秒以 `/proc/self/status` 取 RSS、`getrusage` 取 user/system CPU time，CPU%=ΔCPU秒/Δ單調時間秒×100；再除4得 Guest 總容量百分比。Guest 全機 CPU 取 `/proc/stat` 差分（idle+iowait 視為 idle）。每階段平均依實際間隔加權，區間結束時的 phase 可能跨過邊界；量測期間保留低頻SSH日誌監看，開始時有少量進度查詢，可能增加Guest／Host背景負載；取樣與日誌開銷含在程序資源內，未假稱為純模型成本。每筆 CPU time 還包括輸出檢查，其範圍稍大於模型 wall time。

Peak RSS 是 Linux getrusage 的全生命週期 ru_maxrss（KiB/1024），包含 import、載入、功能測試、兩種量測與最後 hash 核對；不是每階段瞬間峰值、記憶體用量總和或 cgroup MemoryMax。取樣最高 RSS 與真正 lifetime high-water mark 分別保留。

WSL 每約2秒讀 QEMU PID 1281 procfs；一個 Host 邏輯 CPU=100%，除16是當次 WSL 可用CPU容量。Windows 每約5秒 CIM 取得整機CPU與可用RAM；含其他應用程式。Host/QEMU 依正式量測起訖 UTC 過濾（Guest啟動前校時，迴圈內不調時間）；不同層的 CPU／RSS不可相加當成模型用量。

`logs/windows_resources_raw.csv` 是第一次受沙箱限制而欄位缺值的探測，僅作失敗收集證據，未納入統計；有效 Host 檔案為 `logs/windows_monitor/windows_resources_raw.csv`。Vmmem 的 CPU time 欄位持續回報0，無法可靠解釋，分析標為 N/A，不用此值宣稱 WSL 沒有運算。Windows Host 整體 Peak RAM、功耗、溫度與硬體效能計數器：N/A，未可靠量測。

## 六、限制與改善方向

未做1／2／4 vCPU比較：保留既有4 vCPU環境，這是選擇性實驗；沒有以改ORT執行緒或 affinity 冒充核心配置。`resource_comparison.csv` 不產生。Host有其他應用程式執行；未鎖定功耗模式或CPU頻率，TCG延遲包含排程、轉譯及模擬平台開銷。沒有原生ARM基線，不能量化TCG slowdown。

本次衡量固定影像與一個代表模型；小型Development子集不能推論全資料集或其他模型，沒有針對不同照片大小／多人／無臉／壞檔做完整介面邊界試驗。重複檔案讀取可能命中OS page cache，不能稱儲存裝置冷讀取。已載入benchmark與短生命週期API架構不同；API冷啟動分布、長時間穩定性、熱節流、實體板功耗、跨架構逐層數值等價尚未完成。

後續可先在不改權重與門檻下，評估常駐worker減少重複載入；依階段數據決定是否優先處理偵測成本；以獨立實驗記錄1／2／4 vCPU與各自ORT執行緒設定；最後在實體ARM板重做相同協議。任何量化改進幅度均需另做實驗，本報告沒有預估成效。

## 七、簡報用研究摘要

1. **實際架構與規格**：Windows i7-13620H／32 GiB → WSL2 x86-64 → QEMU10.2.1 TCG Cortex-A72、4 vCPU／4096 MiB → Ubuntu24.04 aarch64 → ORT CPU；是虛擬嵌入式板實驗，不是實體Pi測試。
2. **部署與功能**：五模型部署資產核對；代表MobileFaceNet 12/12正常，12/12預期一致。六組原研究clean輸出可比較，其中2/6符合1e-5數值誤差。
3. **推論延遲統計表**：見本摘要下表；每組5 warm-up＋30正式，分清一張臉的ORT與一對照片的完整resident流程。
4. **CPU／記憶體統計表**：見本摘要下表；Guest lifetime Peak RSS 375.359 MiB，與Host/QEMU用量分開。
5. **資源配置比較**：N/A；未執行選擇性核心比較，4 vCPU／ORT intra2／affinity0–3為固定條件。
6. **由證據支持的研究觀察**：
   - 六組同人及六組跨身份結果與預期的一致數為12/12，支持這個Development子集上的部署功能可行性。
   - 同圖同權重不保證分數逐位元一致；六組clean分數差詳列第三節，不能用判定一致取代數值核對。
   - 完整雙圖流程Mean 19,921.327 ms，純單圖辨識Mean 3,458.213 ms；兩者範圍不同，偵測／前處理不可略去。
   - 單次backend載入需70,751.377 ms，現有每次重載的API具有額外成本；尚未做常駐服務改造比較。
   - Guest程序Peak RSS為375.359 MiB；WSL/QEMU另有Guest RAM與模擬器用量，不能用Guest程序RSS代表Host部署成本。
7. **目前限制**：一個代表模型、小型Development子集、固定單一VM配置、Host背景工作、沒有實體ARM板或API冷延遲正式分布；原研究部分數值差異尚未定位。
8. **本次實際工程工作與交付**：環境盤點；五模型資產逐檔雜湊；Development交集選樣與輸入SHA核對；12筆功能驗證；兩組各5＋30延遲試驗；Guest／WSL QEMU／Windows三層資源紀錄；原研究clean輸出核對；統計重算、繁體中文報告、重現腳本與實際畫面；整理為獨立ZIP，未上傳VM與模型權重，依使用者最新指示提交成果至GitHub。

### 簡報用延遲統計表

| 範圍（ms） | 有效／嘗試 | Mean | P50 | P95 | Min | Max | 樣本標準差 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| recognition_onnx_only | 30/30 | 3,458.213 | 3,240.032 | 5,008.658 | 2,310.171 | 5,794.254 | 920.714 |
| resident_full_verification | 30/30 | 19,921.327 | 18,432.512 | 26,885.343 | 16,430.542 | 29,089.133 | 3,268.809 |

### 簡報用CPU與記憶體統計表

| 量測對象 | 區間／指標 | 數值 | 單位／基準 |
| --- | --- | --- | --- |
| Guest 量測程序 | 全程序 lifetime Peak RSS | 375.359 | MiB；getrusage，不含 QEMU |
| Guest 量測程序 | 全程序 user CPU Time | 3,519.685 | s |
| Guest 量測程序 | 全程序 system CPU Time | 98.176 | s |
| Guest 量測程序 | recognition_onnx_only 平均 CPU | 275.692 | %（一核心=100%；四核心上限400%） |
| Guest 量測程序 | resident_full_verification 平均 CPU | 306.208 | %（一核心=100%；四核心上限400%） |
| Guest 量測程序 | recognition_onnx_only 平均 CPU／Guest容量 | 68.923 | %（四 vCPU 總容量=100%） |
| Guest 量測程序 | resident_full_verification 平均 CPU／Guest容量 | 76.552 | %（四 vCPU 總容量=100%） |
| WSL QEMU 程序 | recognition_onnx_only 取樣最大 RSS | 5,369.219 | MiB；包含 Guest RAM 與模擬器 |
| WSL QEMU 程序 | resident_full_verification 取樣最大 RSS | 5,370.172 | MiB；包含 Guest RAM 與模擬器 |
| Windows 整機 | recognition_onnx_only 平均 CPU | 37.211 | %（整機16邏輯CPU容量=100%） |
| Windows 整機 | resident_full_verification 平均 CPU | 36.221 | %（整機16邏輯CPU容量=100%） |

真實畫面：`screenshots/03_linux_environment.jpg` 為 Linux／CPU 證據，`screenshots/04_actual_inference_result.jpg` 為實際模型回應，`screenshots/05_demo_results_and_resources.jpg` 為完整展示與資源畫面。原始 CLI／展示 JSON 位於 logs，相關計時範圍已於第四節分開說明。

所有結論以本資料夾原始紀錄為限。`README.md` 提供實際執行與重算方式，`checks.json` 保存資料一致性檢核。
