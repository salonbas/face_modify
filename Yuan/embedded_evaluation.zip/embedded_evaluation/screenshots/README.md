# 真實畫面證據

均為 2026-11-26 使用既有展示服務實際操作所得的原始 JPEG 截圖，未繪製或改寫畫面內容。這次 UI 推論是正式 resident 量測以外的單次短生命週期 worker 觀測。

- `01_guest_cli_loading.jpg`：Guest 環境已確認、HTTP 驗證已送出、worker 執行中。
- `02_live_guest_resources.jpg`：實際模型 PID、RSS、Guest RAM 與 CPU 取樣。
- `03_linux_environment.jpg`：真正 uname／lscpu 輸出，aarch64、4 CPU、Cortex-A72，並顯示 qemu 身分。
- `04_actual_inference_result.jpg`：實際 worker PID15922／aarch64、cosine、固定門檻、同人判定與程序 Peak RSS。
- `05_demo_results_and_resources.jpg`：完整展示工作台、使用的兩張 Development 原圖、結果、載入時間與資源資訊。

CLI／主畫面原始 JSON 位於 `logs/production_cli_export.json` 與 `logs/production_demo_export.json`。125.06秒為 worker 內部總範圍；服務端請求133.19秒與瀏覽器整輪134.76秒是不同範圍；都不是正式30筆統計平均。主畫面本輪沒有使用既有回放案例的結果。
