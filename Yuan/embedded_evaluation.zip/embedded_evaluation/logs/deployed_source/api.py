from __future__ import annotations

import hmac
import importlib.util
import json
import os
import platform
import subprocess
import sys
import tempfile
import threading
import time
from pathlib import Path

from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.responses import JSONResponse

from .core import MAX_BYTES, MODELS, ROOT, VerificationError, check_assets, decode_image
from .demo import DemoSessions, install_demo


class RequestGuard:
    """Authenticate before multipart parsing, cap the entire encoded request."""
    def __init__(self, app, token, sessions=None):
        self.app, self.token, self.sessions = app, token, sessions

    async def __call__(self, scope, receive, send):
        if scope["type"] != "http" or scope["path"] != "/verify":
            return await self.app(scope, receive, send)
        headers = dict(scope["headers"])
        expected = ("Bearer " + self.token).encode()
        bearer_ok = hmac.compare_digest(headers.get(b"authorization", b""), expected)
        demo_ok = self.sessions is not None and self.sessions.valid(scope)
        if not (bearer_ok or demo_ok):
            return await JSONResponse({"detail": "unauthorized"}, status_code=401)(scope, receive, send)
        chunks, size = [], 0
        while True:
            message = await receive()
            if message["type"] == "http.disconnect":
                return
            size += len(message.get("body", b""))
            if size > 2 * MAX_BYTES + 1024 * 1024:
                return await JSONResponse({"detail": "request_too_large"}, status_code=413)(scope, receive, send)
            chunks.append(message.get("body", b""))
            if not message.get("more_body", False):
                break
        body = b"".join(chunks)
        delivered = False

        async def buffered_receive():
            nonlocal delivered
            if not delivered:
                delivered = True
                return {"type": "http.request", "body": body, "more_body": False}
            return await receive()

        await self.app(scope, buffered_receive, send)


def run_model(assets, model, a, b):
    env = dict(os.environ, OMP_NUM_THREADS="2", OPENBLAS_NUM_THREADS="1", MKL_NUM_THREADS="2",
               CUDA_VISIBLE_DEVICES="", NO_ALBUMENTATIONS_UPDATE="1")
    # Worker does not need the API credential.
    env.pop("FACEVERIFY_TOKEN", None)
    try:
        result = subprocess.run([sys.executable, "-m", "faceverify.worker", "--assets", str(assets),
                                 "--model", model, "--a", str(a), "--b", str(b)], cwd=ROOT,
                                env=env, capture_output=True, text=True,
                                timeout=int(os.environ.get("FACEVERIFY_TIMEOUT", "1800")))
        if result.returncode != 0:
            return {"model": model, "status": "error", "error": "worker_failed"}
        value = json.loads(result.stdout)
        if value.get("model") != model or value.get("status") not in {"ok", "error"}:
            raise ValueError("invalid worker response")
        return value
    except subprocess.TimeoutExpired:
        return {"model": model, "status": "error", "error": "timeout"}
    except (ValueError, OSError):
        return {"model": model, "status": "error", "error": "worker_failed"}


def create_app(asset_root=None, token=None, runner=run_model):
    token = token if token is not None else os.environ.get("FACEVERIFY_TOKEN", "")
    if not token:
        raise RuntimeError("FACEVERIFY_TOKEN must be configured")
    assets = Path(asset_root or os.environ.get("FACEVERIFY_ASSETS", ROOT / "assets")).resolve()
    app = FastAPI(title="ARM64 Face Verification", version="0.1.0")
    sessions = DemoSessions()
    app.add_middleware(RequestGuard, token=token, sessions=sessions)
    install_demo(app, assets, sessions)
    lock = threading.Lock()

    @app.get("/healthz")
    def health():
        return {"status": "alive", "machine": platform.machine(), "cpu_count": os.cpu_count(),
                "python": platform.python_version(), "models": list(MODELS)}

    @app.get("/readyz")
    def ready():
        checks = {name: check_assets(assets, name) for name in MODELS}
        packages = ["numpy", "PIL", "cv2", "onnxruntime", "onnx", "insightface", "torch", "torchvision", "facenet_pytorch"]
        missing = [name for name in packages if importlib.util.find_spec(name) is None]
        ok = not any(checks.values()) and not missing
        return JSONResponse({"status": "assets_verified" if ok else "not_ready",
                             "scope": "asset_checksums_and_package_presence",
                             "models": checks, "missing_packages": missing}, status_code=200 if ok else 503)

    @app.post("/verify")
    def verify(image_a: UploadFile = File(...), image_b: UploadFile = File(...),
               model: str = Form("all"), authorized: bool = Form(False)):
        if not authorized:
            raise HTTPException(400, "authorized=true is required for test photographs")
        if model not in (*MODELS, "all"):
            raise HTTPException(422, "unknown model")
        a_data, b_data = image_a.file.read(MAX_BYTES + 1), image_b.file.read(MAX_BYTES + 1)
        try:
            decode_image(a_data)
            decode_image(b_data)
        except VerificationError as exc:
            raise HTTPException(413 if exc.code == "image_too_large" else 422, exc.code) from exc
        if not lock.acquire(blocking=False):
            raise HTTPException(409, "device_busy")
        try:
            started = time.monotonic()
            selected = MODELS if model == "all" else (model,)
            with tempfile.TemporaryDirectory(prefix="faceverify-") as directory:
                a, b = Path(directory) / "a.image", Path(directory) / "b.image"
                a.write_bytes(a_data)
                b.write_bytes(b_data)
                results = [runner(assets, name, a, b) for name in selected]
            ok = all(result["status"] == "ok" for result in results)
            status = "ok" if ok else ("partial" if any(r["status"] == "ok" for r in results) else "error")
            return JSONResponse({"status": status, "results": results,
                                 "total_seconds": time.monotonic() - started}, status_code=200 if ok else 207)
        finally:
            lock.release()

    return app
