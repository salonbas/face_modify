from __future__ import annotations

import hashlib
import io
import json
import math
from pathlib import Path

import numpy as np
from PIL import Image, ImageOps, UnidentifiedImageError

ROOT = Path(__file__).resolve().parents[1]
MODELS = ("arcface", "facenet", "adaface", "mobilefacenet", "magface")
MAX_BYTES = 8 * 1024 * 1024
MAX_PIXELS = 2_000_000


class VerificationError(Exception):
    def __init__(self, code: str, message: str):
        super().__init__(message)
        self.code = code


def settings():
    return json.loads((ROOT / "config/models.json").read_text(encoding="utf-8"))


def sha256(path: Path) -> str:
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def check_assets(asset_root: Path, model: str) -> list[dict]:
    if model not in MODELS:
        raise ValueError("unknown model")
    assets = settings()["models"][model]["assets"]
    errors = []
    for relative, expected in assets.items():
        path = asset_root / relative
        if not path.is_file():
            errors.append({"path": relative, "status": "missing"})
        elif sha256(path) != expected:
            errors.append({"path": relative, "status": "checksum_mismatch"})
    return errors


def decode_image(data: bytes) -> np.ndarray:
    if len(data) > MAX_BYTES:
        raise VerificationError("image_too_large", "image exceeds 8 MiB")
    try:
        with Image.open(io.BytesIO(data)) as image:
            if image.format not in {"JPEG", "PNG"}:
                raise VerificationError("invalid_image", "only JPEG and PNG are supported")
            if image.width * image.height > MAX_PIXELS:
                raise VerificationError("image_too_large", "image exceeds 2 million pixels")
            if getattr(image, "n_frames", 1) != 1:
                raise VerificationError("invalid_image", "animated images are unsupported")
            rgb = np.asarray(ImageOps.exif_transpose(image).convert("RGB"))
        return rgb[:, :, ::-1].copy()
    except (UnidentifiedImageError, OSError, ValueError, Image.DecompressionBombError) as exc:
        raise VerificationError("invalid_image", "cannot decode image") from exc


def normalized(vector: np.ndarray) -> np.ndarray:
    vector = np.asarray(vector, dtype=np.float64)
    if vector.shape != (512,) or not np.isfinite(vector).all():
        raise VerificationError("invalid_embedding", "expected a finite 512-dimensional vector")
    norm = np.linalg.norm(vector)
    if not math.isfinite(float(norm)) or norm <= 0:
        raise VerificationError("invalid_embedding", "embedding norm must be positive and finite")
    return vector / norm


def decide(model: str, a: np.ndarray, b: np.ndarray) -> dict:
    threshold = settings()["models"][model]["threshold"]
    if not math.isfinite(threshold) or not -1 <= threshold <= 1:
        raise VerificationError("invalid_threshold", "invalid model threshold")
    score = float(np.clip(np.dot(normalized(a), normalized(b)), -1, 1))
    return {"model": model, "status": "ok", "cosine_similarity": score,
            "threshold": threshold, "same_person": score >= threshold,
            "threshold_source": "upstream_lfw_v2_far_1e-2"}
