"""One short-lived process owns one model and exactly one image pair."""
import argparse
import contextlib
import json
import os
import platform
import socket
import sys
import time
from pathlib import Path

from .core import MODELS, VerificationError, check_assets, decode_image, decide


def run(asset_root, model, a, b):
    started = time.monotonic()
    errors = check_assets(asset_root, model)
    if errors:
        return {"model": model, "status": "error", "error": "assets_unavailable", "assets": errors}
    checked = time.monotonic()
    from .backends import load
    embedder = load(asset_root, model)
    loaded = time.monotonic()
    a_vector = embedder.get_embedding(decode_image(a.read_bytes()))
    a_finished = time.monotonic()
    b_vector = embedder.get_embedding(decode_image(b.read_bytes()))
    b_finished = time.monotonic()
    result = decide(model, a_vector, b_vector)
    result["inference_seconds"] = time.monotonic() - started
    result["execution"] = {"machine": platform.machine(), "hostname": socket.gethostname(),
                           "pid": os.getpid(), "cpu_count": os.cpu_count(),
                           "scope": "actual_model_worker_process"}
    result["performance"] = {"assets_check_seconds": checked - started,
                             "model_load_seconds": loaded - checked,
                             "image_a_seconds": a_finished - loaded,
                             "image_b_seconds": b_finished - a_finished}
    if sys.platform.startswith('linux'):
        import resource
        usage = resource.getrusage(resource.RUSAGE_SELF)
        result["performance"].update(peak_rss_mib=usage.ru_maxrss / 1024,
                                     cpu_user_seconds=usage.ru_utime,
                                     cpu_system_seconds=usage.ru_stime,
                                     memory_scope='single model worker peak RSS')
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--assets", type=Path, required=True)
    parser.add_argument("--model", choices=MODELS, required=True)
    parser.add_argument("--a", type=Path, required=True)
    parser.add_argument("--b", type=Path, required=True)
    args = parser.parse_args()
    try:
        with contextlib.redirect_stdout(sys.stderr):
            result = run(args.assets, args.model, args.a, args.b)
    except VerificationError as exc:
        result = {"model": args.model, "status": "error", "error": exc.code}
    except Exception as exc:
        print(f"{type(exc).__name__}: {exc}", file=sys.stderr)
        result = {"model": args.model, "status": "error", "error": "inference_failed"}
    print(json.dumps(result, allow_nan=False))


if __name__ == "__main__":
    main()
