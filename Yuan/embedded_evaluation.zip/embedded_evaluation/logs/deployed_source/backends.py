"""Inference adapters extracted from Yeah/advface/models at the recorded commit.

Model-specific face selection, alignment and normalization are intentionally
preserved. Dependencies are lazy so ONNX-only requests never import torch.
"""
from __future__ import annotations

import importlib.util
import pickle
import sys
import types
from pathlib import Path

import numpy as np

from .core import VerificationError


def source_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def ort_options():
    import onnxruntime as ort
    options = ort.SessionOptions()
    options.intra_op_num_threads = 2
    options.inter_op_num_threads = 1
    options.execution_mode = ort.ExecutionMode.ORT_SEQUENTIAL
    return options


def onnx_model(path):
    from insightface.model_zoo import get_model
    return get_model(str(path), providers=["CPUExecutionProvider"], sess_options=ort_options())


class InsightEmbedder:
    def __init__(self, root: Path, model: str):
        self.arcface = model == "arcface"
        folder = root / "insightface" / ("buffalo_l" if self.arcface else "buffalo_sc")
        self.detector = onnx_model(folder / ("det_10g.onnx" if self.arcface else "det_500m.onnx"))
        self.recognizer = onnx_model(folder / ("w600k_r50.onnx" if self.arcface else "w600k_mbf.onnx"))
        self.detector.prepare(ctx_id=-1, input_size=(640, 640))
        self.recognizer.prepare(ctx_id=-1)

    def get_embedding(self, image):
        from insightface.utils import face_align
        # ArcFace upstream picks max detection score; MobileFaceNet uses the
        # detector's max_num=1 size/centrality ordering. Do not unify these.
        boxes, landmarks = self.detector.detect(image, max_num=0 if self.arcface else 1)
        if len(boxes) == 0 or landmarks is None:
            raise VerificationError("no_face", "no face detected")
        index = int(np.argmax(boxes[:, 4])) if self.arcface else 0
        crop = face_align.norm_crop(image, landmark=landmarks[index], image_size=112)
        return np.asarray(self.recognizer.get_feat(crop), dtype=np.float32).reshape(-1)


class FaceNetEmbedder:
    def __init__(self, root: Path):
        import torch
        from facenet_pytorch import InceptionResnetV1, MTCNN
        self.aligner = MTCNN(image_size=160, margin=0, min_face_size=20,
                             thresholds=[0.6, 0.7, 0.7], factor=0.709,
                             post_process=True, device="cpu", keep_all=False)
        self.model = InceptionResnetV1(pretrained=None, classify=True, num_classes=8631)
        self.model.load_state_dict(torch.load(root / "facenet/20180402-114759-vggface2.pt",
                                              map_location="cpu", weights_only=True))
        self.model.classify = False
        self.model.eval()

    def get_embedding(self, image):
        import torch
        face = self.aligner(image[:, :, ::-1].copy())
        if face is None:
            raise VerificationError("no_face", "FaceNet MTCNN found no face")
        with torch.inference_mode():
            return self.model(face.unsqueeze(0)).squeeze(0).numpy()


def adaface_state(path):
    import torch

    class ModelCheckpoint:
        pass

    if hasattr(torch.serialization, "safe_globals"):
        with torch.serialization.safe_globals([
            (ModelCheckpoint, "pytorch_lightning.callbacks.model_checkpoint.ModelCheckpoint")
        ]):
            return torch.load(path, map_location="cpu", weights_only=True)["state_dict"]

    # Only reached after core.check_assets validates the author's exact hash.
    # This matches upstream's compatibility loader for torch 2.2.2.
    class CheckpointUnpickler(pickle.Unpickler):
        def find_class(self, module, name):
            if (module, name) == ("pytorch_lightning.callbacks.model_checkpoint", "ModelCheckpoint"):
                return ModelCheckpoint
            return super().find_class(module, name)

    loader = types.ModuleType("adaface_checkpoint_pickle")
    for name in dir(pickle):
        setattr(loader, name, getattr(pickle, name))
    loader.Unpickler = CheckpointUnpickler
    return torch.load(path, map_location="cpu", weights_only=False, pickle_module=loader)["state_dict"]


class AdaFaceEmbedder:
    def __init__(self, root: Path):
        base = root / "third_party/adaface"
        net = source_module("official_adaface_net", base / "net.py")
        self.model = net.build_model("ir_50")
        state = adaface_state(root / "adaface/adaface_ir50_ms1mv2.ckpt")
        self.model.load_state_dict({k[6:]: v for k, v in state.items() if k.startswith("model.")}, strict=True)
        self.model.eval()
        sys.path.insert(0, str(base))
        try:
            from face_alignment import mtcnn
            self.aligner = mtcnn.MTCNN(device="cpu", crop_size=(112, 112))
        finally:
            sys.path.remove(str(base))

    def get_embedding(self, image):
        import torch
        from PIL import Image
        _, faces = self.aligner.align_multi(Image.fromarray(image[:, :, ::-1].copy()), limit=1)
        if not faces:
            raise VerificationError("no_face", "AdaFace MTCNN found no face")
        bgr = np.asarray(faces[0])[:, :, ::-1].copy()
        tensor = torch.from_numpy(bgr.transpose(2, 0, 1).copy()).unsqueeze(0).float()
        tensor = (tensor / 255.0 - 0.5) / 0.5
        with torch.inference_mode():
            embedding, _ = self.model(tensor)
        return embedding.squeeze(0).numpy()


class MagFaceEmbedder:
    def __init__(self, root: Path):
        import torch
        net = source_module("official_magface_iresnet", root / "third_party/magface/iresnet.py")
        self.model = net.iresnet100(pretrained=False, num_classes=512)
        state = torch.load(root / "magface/magface_iresnet100_ms1mv2.pth",
                           map_location="cpu", weights_only=True)["state_dict"]
        self.model.load_state_dict({k.removeprefix("features.module."): v for k, v in state.items()
                                   if k.startswith("features.module.")}, strict=True)
        self.model.eval()
        self.detector = onnx_model(root / "insightface/buffalo_sc/det_500m.onnx")
        self.detector.prepare(ctx_id=-1, input_size=(640, 640))

    def get_embedding(self, image):
        import torch
        from insightface.utils import face_align
        boxes, landmarks = self.detector.detect(image, max_num=1)
        if len(boxes) != 1 or landmarks is None:
            raise VerificationError("no_face", "MagFace detector found no face")
        crop = face_align.norm_crop(image, landmark=landmarks[0], image_size=112)
        # Author pipeline: BGR [0,1], without RGB swap or [-1,1] scaling.
        tensor = torch.from_numpy(crop.transpose(2, 0, 1).copy()).unsqueeze(0).float() / 255.0
        with torch.inference_mode():
            return self.model(tensor).squeeze(0).numpy()


def load(root: Path, model: str):
    import cv2
    cv2.setNumThreads(1)
    if model in {"arcface", "mobilefacenet"}:
        return InsightEmbedder(root, model)
    import torch
    torch.set_num_threads(2)
    torch.set_num_interop_threads(1)
    classes = {"facenet": FaceNetEmbedder, "adaface": AdaFaceEmbedder, "magface": MagFaceEmbedder}
    return classes[model](root)
