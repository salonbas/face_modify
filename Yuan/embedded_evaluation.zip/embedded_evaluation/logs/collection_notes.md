# 收集方式與範圍

- 使用者提供 `C:/senior_project/face_modify/Yuan`，以唯讀方式查閱文件、模型來源與資料位置；Development 原圖來自相鄰 Yeah，只有 manifest 宣告的12張被複製到獨立工作目錄及 Guest。
- 2026-11-26 06:46 UTC 啟動獨立 transient unit `faceverify-evaluation.service`，Guest 程序 PID 12307。啟動前確認展示服務 workers 為空，校正 Guest UTC，停止展示服務，配置 User=ubuntu、MemoryMax=3500M、TasksMax=64。實際 unit invocation ID：`6dafe2183eab4955a5aa43774a7fcf38`。
- 量測用現有 Guest Python 與 adapter；沒有在 Yuan 建立環境、執行攻擊或修改研究程式。`scripts/launch_from_wsl.sh` 是本次實際啟動腳本，包含本機工作位置。
- Windows 第一個低權限 sampler 的 CIM 欄位缺值，保存於 logs/windows_resources_raw.csv，未拿缺值或0補出統計。改以可讀取系統計數器的程序重新開始，實際可用數據在 logs/windows_monitor/windows_resources_raw.csv，涵蓋兩組正式量測區間。
- WSL QEMU sampler每約2秒讀取PID1281；Guest量測程序自身每約1秒取樣。Windows約5秒取樣，CIM查詢成本使實際間隔可能超過5秒。所有取樣使用實際時間，不假設完全等間隔。
- 初期以少量 SSH 讀取進度，後改用單一持續 SSH tail 讀 benchmark.log，減少重複握手。這些觀察與 Host 其他工作仍是背景負載，沒有聲稱完全隔離或零量測開銷。
- `guest_system_evidence.txt` 於 unit 執行中收集：展示服務當時應為 inactive，evaluation 為 active；最終恢復狀態另存，不把中途快照的狀態誤作最終結果。
- 既有 formal JSON 僅讀取 clean_cosine、權重、輸入與門檻作參照；整份歷史記錄保存不變，其中 attack 或 held-out 資訊不算本輪新執行結果。
