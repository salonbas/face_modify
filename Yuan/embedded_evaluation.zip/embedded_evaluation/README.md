# ARM64 人臉驗證實測成果

先讀 `REPORT.md`，其中的「簡報用研究摘要」可供進度簡報使用。本資料夾是實際量測成果與重現工具，不包含虛擬機磁碟、模型權重或原始人臉照片。

## 檔案用途

| 檔案 | 內容 |
| --- | --- |
| REPORT.md | 繁體中文架構、協議、實測表格、分析、限制與分工紀錄 |
| environment.json | Windows／WSL／Guest 實際環境及來源程式雜湊核對 |
| model_info.json | 五模型部署資產大小、格式、完整 SHA-256；代表模型 I/O |
| data_provenance.json | 12 張授權 Development 原圖的 SHA、來源及12個配對 |
| protocol.json | 固定模型、batch、暖機／正式次數與計時範圍 |
| validation_results.csv | 逐筆預期、實際、cosine、門檻、偵測、執行、錯誤及原研究差異 |
| validation_summary.json | 功能驗證及既有 clean 輸出的數值一致性摘要 |
| latency_raw.csv | 兩種 series 各5次暖機與30次正式，每次原始紀錄 |
| latency_summary.csv | 正式有效樣本 Mean、P50、P95、Min／Max、樣本標準差與次數 |
| phase_summary.csv | 雙圖流程內部階段延遲；辨識 ORT 與含前處理辨識有重疊 |
| resource_metrics.csv | Guest程序、WSL QEMU、Windows整機的資源摘要及計算基準 |
| checks.json / audit.json | 原始資料與統計摘要的一致性檢核 |
| scripts/ | 本次量測、來源核對、統計及報告腳本 |
| screenshots/ | 實際展示介面、Guest CLI、模型執行與資源畫面 |
| logs/ | 原始 stdout／stderr、環境、資源取樣、UI匯出及既有研究 clean 參照 |

沒有執行選擇性核心配置比較，因此不產生 `resource_comparison.csv`。模型主權重與偵測器大小分別保留，不用一個模型檔大小代表整個部署需求。

## 只重新計算統計

使用 Python 3.12 或以上，從解壓後資料夾執行（標準函式庫即可）：

```powershell
python scripts/summarize.py
python scripts/assemble_environment.py
python scripts/build_report.py
```

`summarize.py` 只讀原始 CSV／JSON，輸出摘要；不會重新推論、不改模型或門檻。P95 為線性插值，標準差 ddof=1。`audit_results.py` 使用 NumPy 進行另一份獨立重算。

## 重跑實驗的前提

需要既有 QEMU Guest 部署：`/opt/faceverify`、其 `.venv`、`config/models.json` 與通過固定 SHA 的 `assets`。Guest 為 Ubuntu aarch64、4 vCPU／4096 MiB、Cortex-A72 TCG；套件版本與執行緒設定見 environment.json。不要在 x86 Python 執行後宣稱是 ARM 實測；腳本會拒絕非 aarch64。

本輪只讀取 `C:/senior_project/face_modify/Yuan` 說明與相鄰 `Yeah` 的指定 Development 影像；沒有修改該研究專案。提供資料的人應自行確認原始資料使用授權。ZIP 不包含照片；組員需要有相同、經授權的原始 LFW Development 檔案，並通過 manifest SHA。

在獨立工作目錄準備影像，`--source-root` 指向原 `Yeah` 根目錄：

```powershell
python scripts/prepare_inputs.py --source-root C:/senior_project/face_modify/Yeah --output ./reproduction_data
```

只會複製 manifest 宣告的12張 Development JPEG；雜湊不符即停止。原圖來源與歷史 formal JSON 的 reference/probe 雜湊已交叉核對；OOS／Test／Reserve 不作為本輪輸入。

## 實際 Guest 執行方法

本輪由 WSL SSH 經2222轉送至 Guest，將 `scripts/` 與 `data/` 複製至獨立 `/opt/faceverify-evaluation`。實際使用的 launch 指令在 `scripts/launch_from_wsl.sh`（其中 Windows 工作路徑是本次實際位置；移機時需換成自己的工作路徑）。Guest wrapper 為 `scripts/run_guest.sh`，結束時恢復 faceverify.service。

**重跑必須使用新的工作目錄與 unit 名稱，保留本次原始結果。** 例如先將 scripts 與備妥的 data 放在 `/opt/faceverify-evaluation-repeat`、所有權設為 ubuntu，確認沒有其他使用者正在推論，然後在 Guest 執行：

```bash
sudo systemctl stop faceverify
sudo systemd-run --unit=faceverify-evaluation-repeat --uid=ubuntu \
  --property=MemoryMax=3500M --property=TasksMax=64 \
  --property=StandardOutput=append:/opt/faceverify-evaluation-repeat/benchmark.log \
  --property=StandardError=append:/opt/faceverify-evaluation-repeat/benchmark.stderr \
  /bin/bash /opt/faceverify-evaluation-repeat/scripts/run_guest.sh /opt/faceverify-evaluation-repeat
```

直接使用的 Python 命令為：

```bash
PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=2 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=2 \
  NO_ALBUMENTATIONS_UPDATE=1 CUDA_VISIBLE_DEVICES='' \
  /opt/faceverify/.venv/bin/python -u scripts/run_guest_benchmark.py \
  --project /opt/faceverify --inputs ./data --out ./results --warmup 5 --measure 30
```

重跑也須同步收集三層資源，並確認 Guest／Host UTC 時間後再開始；不要在正式迴圈內校時：

- Windows PowerShell：`./scripts/collect_windows.ps1 -OutputDirectory ./new_logs` 先盤點；另開程序執行同命令加 `-Monitor`，以 `new_logs/STOP_WINDOWS_MONITOR` 檔案停止。使用新資料夾，避免覆蓋。
- WSL：以原生 Python 執行 `scripts/monitor_qemu_host.py --pid <實際QEMU_PID> --output <新CSV> --stop <新停止標記>`；PID由 `/opt/faceverify-host/vm/qemu.pid` 查，不假定1281永遠不變。
- Guest：benchmark 內建1秒程序／全機 sampler；`scripts/collect_guest_evidence.sh` 取得 uname、lscpu、free、systemd限制與恢復狀態。

Benchmark 結束後確認 `results/status.json` 的 complete=true，將結果、stdout／stderr與三層環境收回新的成果資料夾。再核對 `systemctl is-active faceverify` 為 active；若中途被手動停止，仍須自行恢復服務。不要在同一時間開展示頁面執行推論。

## 展示 API 單次觀測與畫面

正式 resident benchmark 結束並恢復服務後，在 `http://127.0.0.1:8000/` 選擇即時推論、只勾 MobileFaceNet，上傳同一組 `Michelle_Collins_0001.jpg` 與 `Michelle_Collins_0002.jpg`，勾選授權，再按推論。CLI 顯示實際 Guest 診斷回應、worker PID、aarch64、分數與資源。

本輪保存 CLI 匯出為 `logs/production_cli_export.json`、主畫面結果匯出為 `logs/production_demo_export.json`；以 `python scripts/import_demo_observation.py` 組成單次觀測。瀏覽器耗時含診斷指令；服務端時間另有範圍，均不得混入30次 resident 延遲分布。此單次觀測沒有正式冷 API Mean／P95／標準差。

## 說明與封裝

未重新訓練、重做攻擊、改門檻或修改研究結果；五模型完整功能／延遲比較、核心配置比較、實體 ARM 板性能、功耗與數值差異逐層定位均未完成。

打包前使用 `scripts/package_results.py` 產生檔案 SHA-256 清單與 ZIP。GitHub 只存成果 ZIP 至 `Yuan/embedded_evaluation.zip`；不包含 SSH 私鑰、API token、VM、模型權重或原始照片；依使用者最新指示直接提交至 GitHub。
