#!/bin/bash
set -eu
printf '=== UTC ===\n'; date -u --iso-8601=seconds
printf '=== Architecture ===\n'; uname -a; systemd-detect-virt; lscpu
printf '=== OS ===\n'; cat /etc/os-release
printf '=== Memory ===\n'; free -h
printf '=== Evaluation cgroup ===\n'; systemctl show faceverify-evaluation -p User -p MemoryMax -p TasksMax -p CPUAffinity -p Result -p ExecMainStatus -p ActiveState -p MemoryPeak -p CPUUsageNSec
printf '=== Display service ===\n'; systemctl show faceverify -p ActiveState -p User -p MemoryMax -p TasksMax -p ExecStart
