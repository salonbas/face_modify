#!/usr/bin/env bash
set -euo pipefail
root="${1:-/opt/faceverify-evaluation}"
restore() { sudo systemctl start faceverify; }
trap restore EXIT
export PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=2 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=2 NO_ALBUMENTATIONS_UPDATE=1 CUDA_VISIBLE_DEVICES=''
cd "$root"
/opt/faceverify/.venv/bin/python -u scripts/run_guest_benchmark.py --project /opt/faceverify --inputs "$root/data" --out "$root/results" --warmup 5 --measure 30
