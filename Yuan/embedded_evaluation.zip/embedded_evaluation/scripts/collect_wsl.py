import json,os,platform,subprocess
from pathlib import Path
out=Path('/mnt/c/Users/user/Documents/Codex/2026-11-25/qemu/outputs/embedded_evaluation/logs/wsl_environment.json')
pid=int(Path('/opt/faceverify-host/vm/qemu.pid').read_text())
value={'os_release':Path('/etc/os-release').read_text(),'kernel':platform.release(),'architecture':platform.machine(),'logical_cpus':os.cpu_count(),'meminfo':Path('/proc/meminfo').read_text(),'qemu_pid':pid,'qemu_command':Path(f'/proc/{pid}/cmdline').read_bytes().replace(bytes([0]),b' ').decode(),'qemu_version':subprocess.check_output(['qemu-system-aarch64','--version'],text=True),'wsl_technique':'WSL2 x86_64 virtualization; separate QEMU ARM64 full-system TCG emulation','collection_tool':'native WSL Python procfs/platform and qemu --version'}
out.write_text(json.dumps(value,indent=2)+'\n')
