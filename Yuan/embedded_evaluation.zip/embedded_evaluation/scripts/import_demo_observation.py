"""Convert real UI exports into a labeled single cold-worker observation."""
import json
from pathlib import Path
R=Path(__file__).resolve().parents[1]
def j(p):return json.loads((R/p).read_text(encoding='utf-8-sig'))
cli=j('logs/production_cli_export.json');demo=j('logs/production_demo_export.json');m=j('data_provenance.json')
assert demo['mode']=='live' and demo['result_scope']=='live_http_model_workers'
assert len(demo['results'])==1 and demo['results'][0]['model']=='mobilefacenet'
assert cli['images']['a']==m['images']['DEV01_a']['file'] and cli['images']['b']==m['images']['DEV01_b']['file']
row=demo['results'][0];assert row['status']=='ok'
assert row['execution']['machine']=='aarch64'
observation={'sample_id':'DEV-POS-01','model':'mobilefacenet','observation_count':1,
 'http_status':'N/A; UI export retains successful model response, not raw HTTP code',
 'client_elapsed_ms':cli['elapsed_seconds']*1000,
 'client_timing_scope':'browser button through four real Guest diagnostic commands and verify response; includes diagnostics, not isolated HTTP latency',
 'server_reported_request_ms':row['request_total_seconds']*1000,
 'server_timing_scope':'API lock acquired -> temp files + cold worker + parse result; excludes upload and initial decode validation',
 'result':row,'same_images_verified_by_manifest':True,'source_exports':['production_cli_export.json','production_demo_export.json'],
 'formal_cold_http_distribution':'N/A; one observation only; no Mean/P95/sample SD'}
(R/'logs/production_http_observation.json').write_text(json.dumps(observation,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(observation,ensure_ascii=False,indent=2))
