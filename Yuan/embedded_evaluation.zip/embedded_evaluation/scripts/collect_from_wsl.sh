#!/bin/bash
set -euo pipefail
base=/mnt/c/Users/user/Documents/Codex/2026-11-25/qemu
key=/opt/faceverify-host/vm/id_ed25519
ssh -i "$key" -p 2222 -o BatchMode=yes ubuntu@127.0.0.1 'test -f /opt/faceverify-evaluation/results/invariants.json; tar -czf /tmp/faceverify-evaluation-results.tgz -C /opt/faceverify-evaluation results logs; systemctl is-active faceverify; pkill -f "^tail -n 2 -f /opt/faceverify-evaluation/logs/benchmark.log$" || true'
scp -i "$key" -P 2222 -o BatchMode=yes ubuntu@127.0.0.1:/tmp/faceverify-evaluation-results.tgz "$base/work/evaluation/guest-results.tgz"
