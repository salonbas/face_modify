#!/usr/bin/env python3
"""Copy ONLY the twelve preselected, SHA-verified Development JPEGs."""
import argparse,hashlib,json,shutil
from pathlib import Path

p=argparse.ArgumentParser();p.add_argument('--source-root',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--manifest',type=Path,default=Path(__file__).resolve().parents[1]/'data_provenance.json');args=p.parse_args()
m=json.loads(args.manifest.read_text(encoding='utf-8-sig'));args.output.mkdir(parents=True,exist_ok=True)
for image in m['images'].values():
    assert image['source_split']=='attack_dev' and image['pinned_split']=='development'
    source=(args.source_root/image['project_relative_path']).resolve()
    assert source.is_relative_to(args.source_root.resolve())
    assert hashlib.sha256(source.read_bytes()).hexdigest()==image['sha256'],source.name
    shutil.copyfile(source,args.output/image['file'])
(args.output/'input_manifest.json').write_text(json.dumps(m,ensure_ascii=False,indent=2),encoding='utf-8')
print('Prepared '+str(len(m['images']))+' authorized Development files; no other split images read.')
