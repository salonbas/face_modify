#!/usr/bin/env python3
"""Isolated ARM64 evaluation; uses deployed adapters, never trains or changes assets."""
import argparse
import collections
import contextlib
import csv
import datetime
import hashlib
import importlib.metadata
import inspect
import json
import os
from pathlib import Path
import platform
import resource
import shutil
import sys
import threading
import time
import traceback


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()


def dump(path, value):
    Path(path).write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')


class Sampler:
    def __init__(self,path):
        self.path=path;self.phase='initialization';self.iteration=0
        self.stop=threading.Event();self.started=time.perf_counter();self.previous=None
        self.thread=threading.Thread(target=self.loop,daemon=True)

    def context(self,phase,iteration=0):
        self.phase,self.iteration=phase,iteration

    def loop(self):
        fields=['timestamp_utc','elapsed_s','pid','phase','iteration','interval_s','rss_mib',
                'process_cpu_percent_one_core','process_cpu_percent_guest_total','cpu_user_s','cpu_system_s',
                'guest_cpu_percent','guest_memory_used_mib','guest_memory_available_mib','guest_memory_total_mib']
        with self.path.open('w',newline='',encoding='utf-8') as stream:
            writer=csv.DictWriter(stream,fieldnames=fields);writer.writeheader()
            while not self.stop.is_set():
                try:
                    now=time.perf_counter();usage=resource.getrusage(resource.RUSAGE_SELF)
                    values={}
                    for line in Path('/proc/self/status').read_text().splitlines():
                        if ':' in line: values[line.split(':',1)[0]]=line.split(':',1)[1].strip()
                    memory={line.split(':',1)[0]:int(line.split(':',1)[1].split()[0]) for line in Path('/proc/meminfo').read_text().splitlines()}
                    counters=[int(x) for x in Path('/proc/stat').read_text().splitlines()[0].split()[1:9]]
                    total,idle=sum(counters),counters[3]+counters[4]
                    row={'timestamp_utc':utc(),'elapsed_s':now-self.started,'pid':os.getpid(),'phase':self.phase,
                         'iteration':self.iteration,'rss_mib':int(values['VmRSS'].split()[0])/1024,
                         'cpu_user_s':usage.ru_utime,'cpu_system_s':usage.ru_stime,
                         'guest_memory_total_mib':memory['MemTotal']/1024,
                         'guest_memory_used_mib':(memory['MemTotal']-memory['MemAvailable'])/1024,
                         'guest_memory_available_mib':memory['MemAvailable']/1024}
                    if self.previous:
                        old_time,old_cpu,old_total,old_idle=self.previous
                        dt=now-old_time;row['interval_s']=dt
                        row['process_cpu_percent_one_core']=100*max(0,usage.ru_utime+usage.ru_stime-old_cpu)/dt
                        row['process_cpu_percent_guest_total']=row['process_cpu_percent_one_core']/os.cpu_count()
                        if total>old_total: row['guest_cpu_percent']=100*(1-(idle-old_idle)/(total-old_total))
                    self.previous=(now,usage.ru_utime+usage.ru_stime,total,idle)
                    writer.writerow(row);stream.flush()
                except Exception as exc:
                    print('RESOURCE_SAMPLE_ERROR '+repr(exc),file=sys.stderr,flush=True)
                self.stop.wait(1)


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--project',type=Path,default=Path('/opt/faceverify'))
    parser.add_argument('--inputs',type=Path,required=True)
    parser.add_argument('--out',type=Path,required=True)
    parser.add_argument('--warmup',type=int,default=5)
    parser.add_argument('--measure',type=int,default=30)
    args=parser.parse_args()
    assert args.warmup>=5 and args.measure>=30
    assert platform.machine()=='aarch64'
    args.out.mkdir(parents=True,exist_ok=True)
    sampler=Sampler(args.out/'guest_resources_raw.csv');sampler.thread.start()
    status={'complete':False,'started_utc':utc(),'pid':os.getpid(),'machine':platform.machine()}
    dump(args.out/'status.json',status)
    def progress(event,**values):
        status.update(event=event,**values);dump(args.out/'status.json',status)
        print(json.dumps({'event':event,**values},ensure_ascii=False),flush=True)
    try:
        started_import=time.perf_counter_ns()
        sys.path.insert(0,str(args.project))
        import numpy as np
        import cv2
        from faceverify import backends,core
        imported_ms=(time.perf_counter_ns()-started_import)/1e6
        manifest=json.loads((args.inputs/'input_manifest.json').read_text())
        paths={}
        for key,image in manifest['images'].items():
            assert Path(image['file']).name==image['file']
            path=args.inputs/image['file'];assert digest(path)==image['sha256']
            assert image['source_split']=='attack_dev' and image['pinned_split']=='development'
            paths[key]=path
        sampler.context('asset_inventory');progress('asset_inventory')
        config=core.settings();config_before=digest(args.project/'config/models.json')
        asset_inventory={}
        for model,item in config['models'].items():
            entries=[]
            for rel,expected in item['assets'].items():
                path=args.project/'assets'/rel
                actual=digest(path);assert actual==expected,(model,rel,'asset checksum mismatch')
                entries.append({'path':rel,'filename':path.name,'format':path.suffix.lstrip('.'),
                                'bytes':path.stat().st_size,'mib':path.stat().st_size/1048576,
                                'sha256':actual,'expected_sha256':expected,'matched':True})
            asset_inventory[model]={'engine':item['engine'],'threshold':item['threshold'],
                'checkpoint_provenance':item.get('checkpoint'), 'calibration':item.get('calibration'),
                'assets':entries,'benchmarked':model=='mobilefacenet'}
        info={'models':asset_inventory,'configuration_sha256':config_before,
              'source_commit':config['source_commit'],'evaluated_model':'mobilefacenet'}
        dump(args.out/'model_info.json',info)
        environment={'os':Path('/etc/os-release').read_text(),'kernel':platform.release(),'machine':platform.machine(),
            'cpu_count':os.cpu_count(),'affinity':sorted(os.sched_getaffinity(0)),
            'python':sys.version,'packages':{},'environment_variables':{k:os.environ.get(k) for k in
              ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','CUDA_VISIBLE_DEVICES','NO_ALBUMENTATIONS_UPDATE']},
            'cpuinfo':Path('/proc/cpuinfo').read_text(),'meminfo':Path('/proc/meminfo').read_text(),
            'cgroup':Path('/proc/self/cgroup').read_text(),'sampler_interval_seconds':1,
            'source_files':{str(p.relative_to(args.project)):digest(p) for p in (args.project/'faceverify').glob('*.py')}}
        for package in ['numpy','pillow','opencv-python-headless','opencv-python','onnxruntime','onnx','torch','torchvision','insightface','facenet-pytorch']:
            try:environment['packages'][package]=importlib.metadata.version(package)
            except importlib.metadata.PackageNotFoundError:environment['packages'][package]=None
        sampler.context('model_load');progress('model_load')
        start=time.perf_counter_ns()
        with contextlib.redirect_stdout(sys.stderr):engine=backends.load(args.project/'assets','mobilefacenet')
        load_ms=(time.perf_counter_ns()-start)/1e6
        initialization={'script_dependency_import_ms':imported_ms,'model_load_ms':load_ms,
                        'model_load_scope':'backend.load including lazy inference-library imports and two ORT sessions; assets already hash-checked',
                        'peak_rss_after_load_mib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024}
        dump(args.out/'initialization.json',initialization)
        recognition=engine.recognizer
        environment.update(active_providers=recognition.session.get_providers(),
            ort_threads={'intra_op':recognition.session.get_session_options().intra_op_num_threads,
                         'inter_op':recognition.session.get_session_options().inter_op_num_threads},
            opencv_threads=cv2.getNumThreads())
        dump(args.out/'guest_environment.json',environment)
        info['input_spec']=[{'name':x.name,'shape':x.shape,'type':x.type} for x in recognition.session.get_inputs()]
        info['output_spec']=[{'name':x.name,'shape':x.shape,'type':x.type} for x in recognition.session.get_outputs()]
        info['recognizer_parameters']={'input_size':recognition.input_size,'input_mean':recognition.input_mean,'input_std':recognition.input_std}
        dump(args.out/'model_info.json',info)
        (args.out/'installed_recognition_adapter.py').write_text(inspect.getsource(type(recognition)),encoding='utf-8')
        # Functional checks use the unmodified deployed get_embedding method.
        validation=[];valid_candidates=[]
        fields=['sample_id','expected_result','actual_result','cosine_similarity','threshold','detection_status',
                'execution_status','error_message','elapsed_ms','input_a','input_b','upstream_cosine',
                'upstream_absolute_difference','upstream_same_inputs_weights_threshold','expected_matches_actual']
        with (args.out/'validation_results.csv').open('w',newline='',encoding='utf-8') as stream:
            writer=csv.DictWriter(stream,fieldnames=fields);writer.writeheader()
            for pair in manifest['validation_pairs']:
                sampler.context('functional_validation',len(validation)+1)
                progress('functional_validation',sample_id=pair['sample_id'])
                start=time.perf_counter_ns();detected=[]
                row={'sample_id':pair['sample_id'],'expected_result':pair['expected_result'],
                     'threshold':config['models']['mobilefacenet']['threshold'],
                     'input_a':manifest['images'][pair['a']]['file'],'input_b':manifest['images'][pair['b']]['file']}
                try:
                    vectors=[]
                    for key in ['a','b']:
                        vector=engine.get_embedding(core.decode_image(paths[pair[key]].read_bytes()));core.normalized(vector)
                        vectors.append(vector);detected.append(key)
                    result=core.decide('mobilefacenet',*vectors)
                    row.update(actual_result='same_person' if result['same_person'] else 'different_person',
                               cosine_similarity=result['cosine_similarity'],detection_status='A:ok;B:ok',execution_status='ok')
                    if pair['sample_id'] in manifest['benchmark_candidate_order']:valid_candidates.append(pair)
                    if 'upstream_clean_cosine' in pair:
                        row['upstream_cosine']=pair['upstream_clean_cosine']
                        row['upstream_same_inputs_weights_threshold']=(pair['upstream_model_sha256']==config['models']['mobilefacenet']['checkpoint']['sha256'] and pair['upstream_threshold']==row['threshold'])
                        if row['upstream_same_inputs_weights_threshold']:
                            row['upstream_absolute_difference']=abs(result['cosine_similarity']-pair['upstream_clean_cosine'])
                except Exception as exc:
                    row.update(actual_result='error',execution_status='error',
                        detection_status=';'.join(k+(':ok' if k in detected else ':not_completed') for k in ['a','b']),
                        error_message=type(exc).__name__+': '+str(exc))
                    traceback.print_exc(file=sys.stderr)
                row.update(elapsed_ms=(time.perf_counter_ns()-start)/1e6,
                           expected_matches_actual=row.get('actual_result')==pair['expected_result'])
                writer.writerow(row);stream.flush();validation.append(row)
        assert valid_candidates,'No detector-valid Development pair available for latency experiment'
        pair=valid_candidates[0]
        selection={'sample_id':pair['sample_id'],'input_a':manifest['images'][pair['a']],
                   'input_b':manifest['images'][pair['b']], 'selection_rule':manifest['benchmark_selection_rule']}
        dump(args.out/'selected_benchmark_input.json',selection)
        a_path,b_path=paths[pair['a']],paths[pair['b']]
        baseline=core.decide('mobilefacenet',engine.get_embedding(core.decode_image(a_path.read_bytes())),
                             engine.get_embedding(core.decode_image(b_path.read_bytes())))
        # Read one fixed aligned crop to prepare BS=1 ONNX input, outside timed iterations.
        from insightface.utils import face_align
        image=core.decode_image(a_path.read_bytes());boxes,landmarks=engine.detector.detect(image,max_num=1)
        crop=face_align.norm_crop(image,landmark=landmarks[0],image_size=112)
        blob=cv2.dnn.blobFromImages([crop],1.0/recognition.input_std,recognition.input_size,
              (recognition.input_mean,)*3,swapRB=True)
        assert blob.shape==(1,3,112,112)
        # Timing wrappers preserve the deployed adapter's actual computations.
        stage=collections.defaultdict(float)
        def wrapped(name,fn):
            def call(*a,**kw):
                t=time.perf_counter_ns()
                try:return fn(*a,**kw)
                finally:stage[name]+=(time.perf_counter_ns()-t)/1e6
            return call
        engine.detector.detect=wrapped('detection_ms',engine.detector.detect)
        face_align.norm_crop=wrapped('alignment_ms',face_align.norm_crop)
        recognition.get_feat=wrapped('recognition_with_preprocessing_ms',recognition.get_feat)
        original_session=recognition.session
        class SessionProxy:
            def __getattr__(self,name):return getattr(original_session,name)
            def run(self,*a,**kw):return wrapped('recognition_ort_ms',original_session.run)(*a,**kw)
        recognition.session=SessionProxy()
        def full_pipeline():
            t=time.perf_counter_ns();a_data=a_path.read_bytes();b_data=b_path.read_bytes()
            stage['file_read_ms']+=(time.perf_counter_ns()-t)/1e6
            t=time.perf_counter_ns();a_img=core.decode_image(a_data);b_img=core.decode_image(b_data)
            stage['image_decode_ms']+=(time.perf_counter_ns()-t)/1e6
            a_vec=engine.get_embedding(a_img);b_vec=engine.get_embedding(b_img)
            t=time.perf_counter_ns();answer=core.decide('mobilefacenet',a_vec,b_vec)
            stage['similarity_ms']+=(time.perf_counter_ns()-t)/1e6
            return answer
        check=full_pipeline()
        dump(args.out/'instrumentation_check.json',{'baseline_cosine':baseline['cosine_similarity'],
            'instrumented_cosine':check['cosine_similarity'],'absolute_difference':abs(check['cosine_similarity']-baseline['cosine_similarity']),
            'tolerance':1e-6,'passed':abs(check['cosine_similarity']-baseline['cosine_similarity'])<=1e-6})
        assert abs(check['cosine_similarity']-baseline['cosine_similarity'])<=1e-6
        fields=['series','phase','iteration','sample_id','batch_size','started_utc','finished_utc','duration_ms',
                'execution_status','error_message','cpu_user_ms','cpu_system_ms','process_peak_rss_mib_cumulative',
                'cosine_similarity','threshold','actual_result','output_shape','output_norm',
                'file_read_ms','image_decode_ms','detection_ms','alignment_ms','recognition_with_preprocessing_ms',
                'recognition_ort_ms','similarity_ms']
        with (args.out/'latency_raw.csv').open('w',newline='',encoding='utf-8') as stream:
            writer=csv.DictWriter(stream,fieldnames=fields);writer.writeheader()
            for series in ['recognition_onnx_only','resident_full_verification']:
                for phase,count in [('warmup',args.warmup),('measurement',args.measure)]:
                    for iteration in range(1,count+1):
                        sampler.context(series+':'+phase,iteration);stage.clear()
                        row={'series':series,'phase':phase,'iteration':iteration,'sample_id':pair['sample_id'],
                             'batch_size':1,'started_utc':utc()}
                        before=resource.getrusage(resource.RUSAGE_SELF);t=time.perf_counter_ns()
                        try:
                            if series=='recognition_onnx_only':
                                output=original_session.run(recognition.output_names,{recognition.input_name:blob})[0]
                                duration=(time.perf_counter_ns()-t)/1e6
                                assert output.shape==(1,512) and np.isfinite(output).all() and np.linalg.norm(output)>0
                                row.update(output_shape=str(list(output.shape)),output_norm=float(np.linalg.norm(output)))
                            else:
                                answer=full_pipeline();duration=(time.perf_counter_ns()-t)/1e6
                                row.update(cosine_similarity=answer['cosine_similarity'],threshold=answer['threshold'],
                                           actual_result='same_person' if answer['same_person'] else 'different_person')
                                row.update(stage)
                            row['execution_status']='ok'
                        except Exception as exc:
                            duration=(time.perf_counter_ns()-t)/1e6
                            row.update(execution_status='error',error_message=type(exc).__name__+': '+str(exc))
                            traceback.print_exc(file=sys.stderr)
                        after=resource.getrusage(resource.RUSAGE_SELF)
                        row.update(duration_ms=duration,finished_utc=utc(),cpu_user_ms=(after.ru_utime-before.ru_utime)*1000,
                                   cpu_system_ms=(after.ru_stime-before.ru_stime)*1000,
                                   process_peak_rss_mib_cumulative=after.ru_maxrss/1024)
                        writer.writerow(row);stream.flush()
                        progress('latency',series=series,phase=phase,iteration=iteration,duration_ms=duration,
                                 execution_status=row['execution_status'])
        assert digest(args.project/'config/models.json')==config_before
        # These two assets were used by inference; verify they remain byte-identical.
        invariant={'configuration_unchanged':True,'used_asset_hashes_unchanged':True,'assets':{}}
        for rel,expected in config['models']['mobilefacenet']['assets'].items():
            actual=digest(args.project/'assets'/rel);assert actual==expected
            invariant['assets'][rel]=actual
        dump(args.out/'invariants.json',invariant)
        dump(args.out/'final_resource_usage.json',{'peak_rss_mib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024,
             'cpu_user_seconds':resource.getrusage(resource.RUSAGE_SELF).ru_utime,
             'cpu_system_seconds':resource.getrusage(resource.RUSAGE_SELF).ru_stime})
        status.update(complete=True,finished_utc=utc());progress('complete')
    except Exception as exc:
        status.update(error=type(exc).__name__+': '+str(exc),failed_at_utc=utc());dump(args.out/'status.json',status)
        raise
    finally:
        sampler.stop.set();sampler.thread.join(timeout=5)


if __name__=='__main__':main()
