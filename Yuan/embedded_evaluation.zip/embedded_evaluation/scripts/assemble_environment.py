import hashlib,json
from pathlib import Path
R=Path(__file__).resolve().parents[1]
def j(p):return json.loads((R/p).read_text(encoding='utf-8-sig'))
def memtotal(text):return int(next(x for x in text.splitlines() if x.startswith('MemTotal:')).split()[1])*1024
w=j('logs/windows_environment.json');h=j('logs/wsl_environment.json');g=j('logs/guest_environment.json')
g['additional_packages_after_run']=j('logs/guest_additional_packages.json')['packages']
snapshot=R/'logs/deployed_source'
matches={str(p.relative_to(snapshot)):hashlib.sha256(p.read_bytes()).hexdigest()==g['source_files']['faceverify/'+p.name] for p in snapshot.glob('*.py')}
assert all(matches.values())
value={'windows':w,'wsl':h,'guest':g,'wsl_memtotal_bytes':memtotal(h['meminfo']),
       'guest_memtotal_bytes':memtotal(g['meminfo']),'deployment_source_snapshot_matches_guest':matches,
       'layers':['Windows x86-64 host','WSL2 x86-64 Linux virtualization','QEMU TCG ARM64 full-system emulation','Ubuntu aarch64 Guest','CPU ONNX Runtime and model'],
       'not_physical_raspberry_pi':True,'guest_virtual_ram_requested_mib':4096,
       'evaluation_cgroup_memorymax_mib':3500,'evaluation_cgroup_tasksmax':64,
       'resource_comparison':'N/A; optional experiment not performed; kept existing 4-vCPU topology',
       'windows_vmmem_cpu_time':'N/A; Windows counter returned zero and was not reliable'}
(R/'environment.json').write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('Assembled measured environment and verified deployed source snapshots.')
