param([Parameter(Mandatory=$true)][string]$OutputDirectory,[switch]$Monitor)
$ErrorActionPreference = 'Stop'
New-Item -ItemType Directory -Force $OutputDirectory | Out-Null
if (-not $Monitor) {
    $os = Get-CimInstance Win32_OperatingSystem
    $cpu = @(Get-CimInstance Win32_Processor | ForEach-Object {
        [ordered]@{name=$_.Name;physical_cores=$_.NumberOfCores;logical_processors=$_.NumberOfLogicalProcessors;cim_max_clock_speed_mhz=$_.MaxClockSpeed}
    })
    $system = Get-CimInstance Win32_ComputerSystem
    $dimms = @(Get-CimInstance Win32_PhysicalMemory | ForEach-Object { [ordered]@{capacity_bytes=[long]$_.Capacity;reported_speed=$_.Speed} })
    $gpus = @(Get-CimInstance Win32_VideoController | ForEach-Object { [ordered]@{name=$_.Name;driver_version=$_.DriverVersion;used_by_guest_inference=$false} })
    [long]$installedBytes = 0
    foreach ($dimm in $dimms) { $installedBytes += [long]$dimm.capacity_bytes }
    [ordered]@{captured_utc=[DateTimeOffset]::UtcNow.ToString('o');os=[ordered]@{caption=$os.Caption;version=$os.Version;build=$os.BuildNumber;architecture=$os.OSArchitecture};cpu=$cpu;memory=[ordered]@{installed_dimm_bytes=$installedBytes;computer_system_reported_bytes=[long]$system.TotalPhysicalMemory;os_visible_bytes=[long]$os.TotalVisibleMemorySize*1024;modules=$dimms};hypervisor_present=$system.HypervisorPresent;gpus=$gpus;wslconfig_override_exists=(Test-Path (Join-Path $env:USERPROFILE '.wslconfig'));collection_tool='PowerShell Get-CimInstance; no identifiers or process titles collected'} |
        ConvertTo-Json -Depth 8 | Set-Content -Encoding utf8 (Join-Path $OutputDirectory 'windows_environment.json')
    exit 0
}
$stopFile = Join-Path $OutputDirectory 'STOP_WINDOWS_MONITOR'
$csvFile = Join-Path $OutputDirectory 'windows_resources_raw.csv'
if (Test-Path $stopFile) { throw 'Stop marker already exists; use a fresh output directory.' }
if (Test-Path $csvFile) { throw 'Raw monitoring file already exists; preserve it and use a fresh directory.' }
$watch = [System.Diagnostics.Stopwatch]::StartNew()
while (-not (Test-Path $stopFile)) {
    $cpu = $null; $free = $null; $vmmemRss = $null; $vmmemCpu = $null
    try { $cpu = (Get-CimInstance Win32_PerfFormattedData_PerfOS_Processor -Filter "Name='_Total'").PercentProcessorTime } catch { }
    try { $free = [long](Get-CimInstance Win32_OperatingSystem).FreePhysicalMemory*1024 } catch { }
    try {
        $vm = @(Get-Process -Name 'vmmemWSL','vmmem' -ErrorAction SilentlyContinue)
        if ($vm.Count -gt 0) {
            $vmmemRss = ($vm | Measure-Object WorkingSet64 -Sum).Sum
            $vmmemCpu = ($vm | ForEach-Object { $_.TotalProcessorTime.TotalSeconds } | Measure-Object -Sum).Sum
        }
    } catch { }
    [pscustomobject][ordered]@{timestamp_utc=[DateTimeOffset]::UtcNow.ToString('o');elapsed_s=$watch.Elapsed.TotalSeconds;host_total_cpu_percent=$cpu;host_available_ram_bytes=$free;wsl_process_working_set_bytes=$vmmemRss;wsl_process_cpu_time_s=$vmmemCpu;scope='Windows whole-host CPU; WSL process values are separate'} |
        Export-Csv -LiteralPath $csvFile -Append -NoTypeInformation -Encoding utf8
    Start-Sleep -Seconds 5
}
Write-Output 'Windows resource monitor stopped.'
