#!/usr/bin/env python3
import argparse,csv,datetime,os,time
from pathlib import Path

p=argparse.ArgumentParser();p.add_argument('--pid',type=int,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--stop',type=Path,required=True);args=p.parse_args()
assert not args.output.exists(),'Preserve existing raw monitoring records'
previous=None;started=time.perf_counter();ticks=os.sysconf('SC_CLK_TCK');page=os.sysconf('SC_PAGE_SIZE')
with args.output.open('w',newline='',encoding='utf-8') as stream:
    fields=['timestamp_utc','elapsed_s','pid','interval_s','qemu_rss_mib','qemu_cpu_time_s','qemu_cpu_percent_one_core','qemu_cpu_percent_wsl_capacity','wsl_logical_cpus']
    writer=csv.DictWriter(stream,fieldnames=fields);writer.writeheader()
    while not args.stop.exists():
        raw=Path(f'/proc/{args.pid}/stat').read_text();f=raw[raw.rfind(')')+2:].split()
        now=time.perf_counter();cpu=(int(f[11])+int(f[12]))/ticks
        row={'timestamp_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'elapsed_s':now-started,'pid':args.pid,
             'qemu_rss_mib':int(f[21])*page/1048576,'qemu_cpu_time_s':cpu,'wsl_logical_cpus':os.cpu_count()}
        if previous:
            dt=now-previous[0];row.update(interval_s=dt,qemu_cpu_percent_one_core=100*(cpu-previous[1])/dt,
                qemu_cpu_percent_wsl_capacity=100*(cpu-previous[1])/dt/os.cpu_count())
        writer.writerow(row);stream.flush();previous=(now,cpu);time.sleep(2)
print('QEMU Host monitor stopped.')
