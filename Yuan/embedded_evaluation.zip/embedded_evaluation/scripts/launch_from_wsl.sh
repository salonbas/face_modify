#!/bin/bash
set -euo pipefail
base=/mnt/c/Users/user/Documents/Codex/2026-11-25/qemu
key=/opt/faceverify-host/vm/id_ed25519
sshargs=(-i "$key" -p 2222 -o BatchMode=yes -o ConnectTimeout=30)
scp -i "$key" -P 2222 -o BatchMode=yes "$base/work/evaluation/payload.tar" ubuntu@127.0.0.1:/tmp/evaluation-payload.tar
ssh "${sshargs[@]}" ubuntu@127.0.0.1 'sudo mkdir -p /opt/faceverify-evaluation; sudo chown ubuntu:ubuntu /opt/faceverify-evaluation; tar -xf /tmp/evaluation-payload.tar -C /opt/faceverify-evaluation; mkdir -p /opt/faceverify-evaluation/logs; bash -n /opt/faceverify-evaluation/scripts/run_guest.sh'
ssh "${sshargs[@]}" ubuntu@127.0.0.1 "sudo date -u -s '$(date -u +%Y-%m-%dT%H:%M:%SZ)'; sudo systemctl stop faceverify; sudo systemd-run --unit=faceverify-evaluation --uid=ubuntu --property=MemoryMax=3500M --property=TasksMax=64 --property=StandardOutput=append:/opt/faceverify-evaluation/logs/benchmark.log --property=StandardError=append:/opt/faceverify-evaluation/logs/benchmark.stderr /bin/bash /opt/faceverify-evaluation/scripts/run_guest.sh"
