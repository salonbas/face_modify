"""Package only evaluation artifacts, with SHA-256 file manifest."""
import hashlib,json,zipfile
from pathlib import Path
R=Path(__file__).resolve().parents[1]
assert json.loads((R/'checks.json').read_text(encoding='utf-8'))['status']['complete']
assert json.loads((R/'audit.json').read_text(encoding='utf-8'))['all_passed']
files=[p for p in sorted(R.rglob('*')) if p.is_file() and '__pycache__' not in p.parts and p.name!='SHA256SUMS.txt' and not p.name.startswith('STOP_')]
for p in files:
    assert p.suffix.lower() not in ['.onnx','.pt','.ckpt','.pth','.qcow2','.pem','.key'],p
    if p.suffix.lower() in ['.jpg','.jpeg']:assert p.parent.name=='screenshots',p
manifest='\n'.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.relative_to(R).as_posix() for p in files)+'\n'
(R/'SHA256SUMS.txt').write_text(manifest,encoding='utf-8')
target=R.parent/'embedded_evaluation.zip'
with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in files+[R/'SHA256SUMS.txt']:z.write(p,arcname=R.name+'/'+p.relative_to(R).as_posix())
with zipfile.ZipFile(target) as z:assert z.testzip() is None
print(json.dumps({'path':str(target),'bytes':target.stat().st_size,'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'git_blob_sha1':hashlib.sha1(b'blob '+str(target.stat().st_size).encode()+b'\0'+target.read_bytes()).hexdigest()},indent=2))
