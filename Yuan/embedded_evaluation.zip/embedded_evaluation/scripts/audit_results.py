"""Independent NumPy audit of raw samples, summary values and source hashes."""
import csv,hashlib,json
from pathlib import Path
import numpy as np
R=Path(__file__).resolve().parents[1]
def read(p):
    with (R/p).open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
raw=read('latency_raw.csv');summary=read('latency_summary.csv');validation=read('validation_results.csv')
checks=[]
def check(name,condition):
    checks.append({'check':name,'passed':bool(condition)});assert condition,name
check('raw_records_exactly_70',len(raw)==70)
for s in summary:
    rows=[x for x in raw if x['series']==s['series']]
    for phase,count in [('warmup',5),('measurement',30)]:
        selected=[x for x in rows if x['phase']==phase]
        check(s['series']+'_'+phase+'_iteration_sequence',sorted(int(x['iteration']) for x in selected)==list(range(1,count+1)))
        check(s['series']+'_'+phase+'_batch_1',all(x['batch_size']=='1' for x in selected))
    a=np.array([float(x['duration_ms']) for x in rows if x['phase']=='measurement' and x['execution_status']=='ok'])
    expected={'mean_ms':a.mean(),'median_p50_ms':np.median(a),'p95_ms':np.quantile(a,.95,method='linear'),
        'min_ms':a.min(),'max_ms':a.max(),'sample_stddev_ms':a.std(ddof=1)}
    for key,value in expected.items():check(s['series']+'_'+key,abs(value-float(s[key]))<=1e-7)
    check(s['series']+'_valid_count',len(a)==int(s['valid_count']))
check('validation_12_unique_ids',len(validation)==12 and len({x['sample_id'] for x in validation})==12)
manifest=json.loads((R/'data_provenance.json').read_text(encoding='utf-8'))
check('development_only',not manifest['forbidden_splits_used'] and all(x['source_split']=='attack_dev' and x['pinned_split']=='development' for x in manifest['images'].values()))
check('threshold_not_retuned',all(float(x['threshold'])==.1633139401674271 for x in validation))
config=json.loads((R/'logs/deployed_models_config.json').read_text(encoding='utf-8'))
info=json.loads((R/'model_info.json').read_text(encoding='utf-8'))
check('deployed_config_snapshot_sha_matches_guest',hashlib.sha256((R/'logs/deployed_models_config.json').read_bytes()).hexdigest()==info['configuration_sha256'])
check('all_asset_actual_hashes_match_fixed_configuration',all(x['sha256']==x['expected_sha256'] and x['matched'] for model in info['models'].values() for x in model['assets']))
for pair in manifest['validation_pairs']:
    if 'upstream_record' not in pair:continue
    record=json.loads((R/'logs/upstream_records'/Path(pair['upstream_record']).name).read_text(encoding='utf-8'))
    key=record['key']
    check(pair['sample_id']+'_historical_input_hashes',key['reference_sha256']==manifest['images'][pair['a']]['sha256'] and key['probe_sha256']==manifest['images'][pair['b']]['sha256'])
    check(pair['sample_id']+'_historical_model_threshold_score',key['model_hashes']['mobilefacenet']==pair['upstream_model_sha256'] and key['thresholds']['mobilefacenet']==pair['upstream_threshold'] and record['models']['mobilefacenet']['clean_cosine']==pair['upstream_clean_cosine'])
check('original_calibration_json_sha_matches_config',hashlib.sha256((R/'logs/mobilefacenet_upstream_calibration.json').read_bytes()).hexdigest()==config['models']['mobilefacenet']['calibration']['sha256'])
invariants=json.loads((R/'logs/invariants.json').read_text(encoding='utf-8'))
check('used_weights_and_configuration_unchanged',invariants['configuration_unchanged'] and invariants['used_asset_hashes_unchanged'])
output={'all_passed':all(x['passed'] for x in checks),'numpy_version':np.__version__,'checks':checks,'absolute_statistic_tolerance':1e-7,'outliers_removed':0}
(R/'audit.json').write_text(json.dumps(output,indent=2)+'\n',encoding='utf-8')
print('Independent audit passed: '+str(len(checks))+' checks.')
