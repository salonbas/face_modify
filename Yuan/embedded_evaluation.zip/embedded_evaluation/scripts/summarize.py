#!/usr/bin/env python3
"""Recompute statistics strictly from preserved CSVs (stdlib only)."""
import argparse,csv,datetime,hashlib,json,math,statistics
from pathlib import Path

p=argparse.ArgumentParser();p.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1]);a=p.parse_args();root=a.root
def read(name):
    with (root/name).open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def save(name,rows):
    assert rows
    with (root/name).open('w',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def js(name):return json.loads((root/name).read_text(encoding='utf-8-sig'))
def quantile(values,q):
    v=sorted(values);index=(len(v)-1)*q;low=math.floor(index);high=math.ceil(index)
    return v[low]+(v[high]-v[low])*(index-low)
raw=read('latency_raw.csv');summary=[]
for series in ['recognition_onnx_only','resident_full_verification']:
    warm=[r for r in raw if r['series']==series and r['phase']=='warmup']
    formal=[r for r in raw if r['series']==series and r['phase']=='measurement']
    valid=[r for r in formal if r['execution_status']=='ok'];v=[float(r['duration_ms']) for r in valid]
    assert len(warm)>=5 and len(formal)>=30 and all(r['batch_size']=='1' for r in warm+formal)
    assert all(math.isfinite(x) and x>0 for x in v)
    summary.append(dict(series=series,unit='ms',warmup_count=len(warm),attempt_count=len(formal),valid_count=len(v),
        failure_count=len(formal)-len(v),mean_ms=statistics.mean(v),median_p50_ms=statistics.median(v),
        p95_ms=quantile(v,.95),min_ms=min(v),max_ms=max(v),sample_stddev_ms=statistics.stdev(v),
        sequential_throughput_per_s=1000/statistics.mean(v)))
save('latency_summary.csv',summary)
validation=read('validation_results.csv')
validation_summary={'total':len(validation),'completed':sum(r['execution_status']=='ok' for r in validation),
    'failed':sum(r['execution_status']!='ok' for r in validation),
    'expected_matches_actual':sum(r['expected_matches_actual']=='True' for r in validation),
    'subset_only_not_generalization_accuracy':True,'upstream_tolerance':1e-5,
    'upstream_comparable':sum(r['upstream_same_inputs_weights_threshold']=='True' for r in validation),
    'upstream_within_tolerance':sum(bool(r['upstream_absolute_difference']) and float(r['upstream_absolute_difference'])<=1e-5 for r in validation)}
(root/'validation_summary.json').write_text(json.dumps(validation_summary,indent=2)+'\n',encoding='utf-8')
resources=[]
def metric(scope,phase,name,value,unit,tool,notes):
    resources.append(dict(scope=scope,phase=phase,metric=name,value=value,unit=unit,tool=tool,notes=notes))
guest=read('logs/guest_resources_raw.csv')
for phase in ['whole_evaluation','recognition_onnx_only:measurement','resident_full_verification:measurement']:
    rows=guest if phase=='whole_evaluation' else [r for r in guest if r['phase']==phase]
    def weighted(col):
        pairs=[(float(r[col]),float(r['interval_s'])) for r in rows if r.get(col) and r.get('interval_s')]
        return sum(x*w for x,w in pairs)/sum(w for x,w in pairs) if pairs else 'N/A'
    for col,unit in [('process_cpu_percent_one_core','percent_100_per_core'),('process_cpu_percent_guest_total','percent_of_4_vcpu_capacity'),('guest_cpu_percent','percent_guest_total')]:
        v=[float(r[col]) for r in rows if r.get(col)]
        metric('ARM64_Guest',phase,col+'_time_weighted_mean',weighted(col),unit,'procfs + getrusage; ~1s','Intervals classified by phase at interval end; boundary samples can straddle phases; observer included')
        metric('ARM64_Guest',phase,col+'_sampled_peak',max(v) if v else 'N/A',unit,'procfs + getrusage; ~1s','Sampled interval maximum, not instantaneous maximum')
    rss=[float(r['rss_mib']) for r in rows if r.get('rss_mib')]
    metric('ARM64_Guest',phase,'process_sampled_rss_max',max(rss) if rss else 'N/A','MiB','/proc/self/status VmRSS','Sample maximum; separate from lifetime Peak RSS')
    for col in ['guest_memory_used_mib','guest_memory_available_mib']:
        values=[float(r[col]) for r in rows if r.get(col)]
        for label,fn in [('sample_mean',statistics.mean),('sample_min',min),('sample_max',max)]:
            metric('ARM64_Guest',phase,col+'_'+label,fn(values) if values else 'N/A','MiB','/proc/meminfo ~1s','Used = MemTotal - MemAvailable; includes Guest OS and other processes')
final=js('logs/final_resource_usage.json');init=js('logs/initialization.json')
for key in ['peak_rss_mib','cpu_user_seconds','cpu_system_seconds']:
    metric('ARM64_Guest','whole_evaluation',key,final[key],'MiB' if 'mib' in key else 's','resource.getrusage(RUSAGE_SELF)','Lifetime from process start through final asset hash verification; includes validation, imports and sampler')
for key in ['script_dependency_import_ms','model_load_ms']:
    metric('ARM64_Guest','initialization',key,init[key],'ms','perf_counter_ns',init.get('model_load_scope',''))
for s in summary:
    rows=[r for r in raw if r['series']==s['series'] and r['phase']=='measurement' and r['execution_status']=='ok']
    cpu=sum(float(r['cpu_user_ms'])+float(r['cpu_system_ms']) for r in rows)
    wall=sum(float(r['duration_ms']) for r in rows)
    metric('ARM64_Guest',s['series'],'measured_iterations_cpu_time',cpu/1000,'s','getrusage before/after each iteration','Includes output validation and instrumentation; wall timing scope is narrower')
    metric('ARM64_Guest',s['series'],'sequential_throughput',s['sequential_throughput_per_s'],'image_or_pair_per_s','1000 / mean_latency_ms','Image/s for ONNX-only; pair/s for full verification; model loaded; not concurrent server throughput')
    if s['series']=='resident_full_verification':
        phases=[]
        for col in ['file_read_ms','image_decode_ms','detection_ms','alignment_ms','recognition_with_preprocessing_ms','recognition_ort_ms','similarity_ms']:
            vals=[float(r[col]) for r in rows if r.get(col)]
            phases.append(dict(stage=col,mean_ms=statistics.mean(vals),median_ms=statistics.median(vals),p95_ms=quantile(vals,.95),valid_count=len(vals),note='recognition_ort_ms nested inside recognition_with_preprocessing_ms; do not add twice'))
        save('phase_summary.csv',phases)
qemu=read('logs/qemu_resources_raw.csv')
windows=read('logs/windows_monitor/windows_resources_raw.csv')
def dt(s):return datetime.datetime.fromisoformat(s.replace('Z','+00:00'))
for s in summary:
    rows=[r for r in raw if r['series']==s['series'] and r['phase']=='measurement']
    start=min(dt(r['started_utc']) for r in rows);end=max(dt(r['finished_utc']) for r in rows)
    for scope,source,columns in [('WSL_QEMU_process',qemu,[('qemu_cpu_percent_one_core','percent_100_per_host_logical_cpu'),('qemu_cpu_percent_wsl_capacity','percent_of_16_wsl_cpus'),('qemu_rss_mib','MiB')]),('Windows_whole_host',windows,[('host_total_cpu_percent','percent_of_16_host_logical_cpus'),('host_available_ram_bytes','bytes')])]:
        selected=[r for r in source if start<=dt(r['timestamp_utc'])<=end]
        for col,unit in columns:
            v=[float(r[col]) for r in selected if r.get(col)]
            for label,value in [('sample_mean',statistics.mean(v) if v else 'N/A'),('sample_max',max(v) if v else 'N/A'),('sample_count',len(v))]:
                metric(scope,s['series'],col+'_'+label,value,'count' if label=='sample_count' else unit,'WSL procfs ~2s' if scope=='WSL_QEMU_process' else 'Windows CIM ~5s','Timestamp-filtered to measured-series window; sample mean not time weighted; Host includes unrelated workloads')
save('resource_metrics.csv',resources)
checks={'raw_rows':len(raw),'expected_rows':70,'latency_summary_recomputed':True,'validation_rows':len(validation),
    'instrumentation_check':js('logs/instrumentation_check.json'),'invariants':js('logs/invariants.json'),
    'status':js('logs/status.json'),'outliers_removed':0,'statistics_implementation':'stdlib mean/median/stdev; P95 linear interpolation',
    'units':{'latency':'ms','memory':'MiB=1048576 bytes','peak_rss_linux':'ru_maxrss KiB /1024'}}
assert checks['status']['complete'] and checks['instrumentation_check']['passed']
assert len(raw)==70 and len(validation)==12
(root/'checks.json').write_text(json.dumps(checks,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'latency':summary,'validation':validation_summary},indent=2))
